var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["af55c0cd-7781-47df-b00d-0fa9cd2e908c","a10827ae-bf7e-459b-be24-2063517ad9d5","89076ad2-17ed-4cc2-a6b0-a2f2c7647f8b","948032ca-676c-4ae7-b0c8-fb7ac37bec7c","d44d015c-0f5a-42d6-a705-13c534991470","62b639e0-262b-4def-aeae-9b21305fdd2e","27a6a3ea-51bb-455d-9790-dd4500e68cef","53186617-b397-4792-b0ee-a61374274332","82cd349d-0a71-49f3-9b66-f2ee881ae8d3","3c99ad97-d7bb-4f1e-b8a0-7c6154dd7bb7","a9fbe12f-d104-4696-86e6-48f6cc4a55dd","dc7efe7d-89e9-4c27-aa1e-07265e0d4b29","a7dac581-97e5-4de9-b678-6e530e67abba","52e8ebe4-e2b0-4fde-89c5-c3837775c2a0","c39de7f5-4ffa-4ad4-8b55-9db3bfbe6751"],"propsByKey":{"af55c0cd-7781-47df-b00d-0fa9cd2e908c":{"name":"trex","sourceUrl":null,"frameSize":{"x":524,"y":160},"frameCount":1,"looping":true,"frameDelay":12,"version":"8uUuiJj5WIZ4qCNg5fnrfOYM47WlKfj8","loadedFromSource":true,"saved":true,"sourceSize":{"x":524,"y":160},"rootRelativePath":"assets/af55c0cd-7781-47df-b00d-0fa9cd2e908c.png"},"a10827ae-bf7e-459b-be24-2063517ad9d5":{"name":"ground1","sourceUrl":"assets/v3/animations/_zVr-Ht4cJETV573GIhR_widaY8yD24II_c3xbDv5s4/a10827ae-bf7e-459b-be24-2063517ad9d5.png","frameSize":{"x":1596,"y":26},"frameCount":1,"looping":true,"frameDelay":4,"version":"7xU8BxP_P2uveDpf4ZCQfo88FBVmMwIh","loadedFromSource":true,"saved":true,"sourceSize":{"x":1596,"y":26},"rootRelativePath":"assets/v3/animations/_zVr-Ht4cJETV573GIhR_widaY8yD24II_c3xbDv5s4/a10827ae-bf7e-459b-be24-2063517ad9d5.png"},"89076ad2-17ed-4cc2-a6b0-a2f2c7647f8b":{"name":"ground2","sourceUrl":"assets/v3/animations/_zVr-Ht4cJETV573GIhR_widaY8yD24II_c3xbDv5s4/89076ad2-17ed-4cc2-a6b0-a2f2c7647f8b.png","frameSize":{"x":2377,"y":12},"frameCount":1,"looping":true,"frameDelay":4,"version":"3CeTkkLEpEhJfoiGiKRvL4z_LXEa3lBw","loadedFromSource":true,"saved":true,"sourceSize":{"x":2377,"y":12},"rootRelativePath":"assets/v3/animations/_zVr-Ht4cJETV573GIhR_widaY8yD24II_c3xbDv5s4/89076ad2-17ed-4cc2-a6b0-a2f2c7647f8b.png"},"948032ca-676c-4ae7-b0c8-fb7ac37bec7c":{"name":"cloud","sourceUrl":null,"frameSize":{"x":386,"y":267},"frameCount":1,"looping":true,"frameDelay":12,"version":".NarIiU8WZTI_XZizcPk1f3wPrAp0Jvy","loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":267},"rootRelativePath":"assets/948032ca-676c-4ae7-b0c8-fb7ac37bec7c.png"},"d44d015c-0f5a-42d6-a705-13c534991470":{"name":"obstacle1","sourceUrl":null,"frameSize":{"x":389,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"Al6DaqrOCYc7lsi.yHSZwXvkUZkZsdug","loadedFromSource":true,"saved":true,"sourceSize":{"x":389,"y":400},"rootRelativePath":"assets/d44d015c-0f5a-42d6-a705-13c534991470.png"},"62b639e0-262b-4def-aeae-9b21305fdd2e":{"name":"obstacle2","sourceUrl":null,"frameSize":{"x":264,"y":243},"frameCount":1,"looping":true,"frameDelay":12,"version":"OpD4VlH1LsTebZNGqf3kI6uAcTegWhjm","loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":243},"rootRelativePath":"assets/62b639e0-262b-4def-aeae-9b21305fdd2e.png"},"27a6a3ea-51bb-455d-9790-dd4500e68cef":{"name":"obstacle3","sourceUrl":null,"frameSize":{"x":399,"y":377},"frameCount":1,"looping":true,"frameDelay":12,"version":"Fopyls54G8mqhPPivUV0PIJG6lIPWKI_","loadedFromSource":true,"saved":true,"sourceSize":{"x":399,"y":377},"rootRelativePath":"assets/27a6a3ea-51bb-455d-9790-dd4500e68cef.png"},"53186617-b397-4792-b0ee-a61374274332":{"name":"obstacle4","sourceUrl":null,"frameSize":{"x":179,"y":396},"frameCount":1,"looping":true,"frameDelay":12,"version":"4BbjJ1TporKQff1lPz.ZuMrrfXyDZcTK","loadedFromSource":true,"saved":true,"sourceSize":{"x":179,"y":396},"rootRelativePath":"assets/53186617-b397-4792-b0ee-a61374274332.png"},"82cd349d-0a71-49f3-9b66-f2ee881ae8d3":{"name":"obstacle5","sourceUrl":null,"frameSize":{"x":396,"y":224},"frameCount":1,"looping":true,"frameDelay":12,"version":"bVmRlCAD7objSU5ZJj8D0ZSnlajG9qKG","loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":224},"rootRelativePath":"assets/82cd349d-0a71-49f3-9b66-f2ee881ae8d3.png"},"3c99ad97-d7bb-4f1e-b8a0-7c6154dd7bb7":{"name":"obstacle6","sourceUrl":null,"frameSize":{"x":390,"y":400},"frameCount":1,"looping":true,"frameDelay":12,"version":"_IA3LGUWg4..7ClfBuXFb7BhtE7SMYYt","loadedFromSource":true,"saved":true,"sourceSize":{"x":390,"y":400},"rootRelativePath":"assets/3c99ad97-d7bb-4f1e-b8a0-7c6154dd7bb7.png"},"a9fbe12f-d104-4696-86e6-48f6cc4a55dd":{"name":"trex_collided","sourceUrl":null,"frameSize":{"x":561,"y":445},"frameCount":1,"looping":true,"frameDelay":12,"version":"c9MFv98Srgzi4X2M1NFoDBOIbaq7758z","loadedFromSource":true,"saved":true,"sourceSize":{"x":561,"y":445},"rootRelativePath":"assets/a9fbe12f-d104-4696-86e6-48f6cc4a55dd.png"},"dc7efe7d-89e9-4c27-aa1e-07265e0d4b29":{"name":"gameOver","sourceUrl":"assets/v3/animations/JI0MyHYDGYHup_lac_GM8hY6BwPSKo7AE9BueVVsV48/dc7efe7d-89e9-4c27-aa1e-07265e0d4b29.png","frameSize":{"x":381,"y":21},"frameCount":1,"looping":true,"frameDelay":4,"version":"qLJ.K9Tg1fQGDdTWSdDN9Y76BM4o9xfV","loadedFromSource":true,"saved":true,"sourceSize":{"x":381,"y":21},"rootRelativePath":"assets/v3/animations/JI0MyHYDGYHup_lac_GM8hY6BwPSKo7AE9BueVVsV48/dc7efe7d-89e9-4c27-aa1e-07265e0d4b29.png"},"a7dac581-97e5-4de9-b678-6e530e67abba":{"name":"restart","sourceUrl":"assets/v3/animations/JI0MyHYDGYHup_lac_GM8hY6BwPSKo7AE9BueVVsV48/a7dac581-97e5-4de9-b678-6e530e67abba.png","frameSize":{"x":75,"y":64},"frameCount":1,"looping":true,"frameDelay":4,"version":"FheYDWd0xWFwUoSh6K7HN6JoxUvmQ3lg","loadedFromSource":true,"saved":true,"sourceSize":{"x":75,"y":64},"rootRelativePath":"assets/v3/animations/JI0MyHYDGYHup_lac_GM8hY6BwPSKo7AE9BueVVsV48/a7dac581-97e5-4de9-b678-6e530e67abba.png"},"52e8ebe4-e2b0-4fde-89c5-c3837775c2a0":{"name":"background1","sourceUrl":null,"frameSize":{"x":315,"y":168},"frameCount":1,"looping":true,"frameDelay":12,"version":"MDTmQokF0oHgvoStej0qXBxyTF1BHawq","loadedFromSource":true,"saved":true,"sourceSize":{"x":315,"y":168},"rootRelativePath":"assets/52e8ebe4-e2b0-4fde-89c5-c3837775c2a0.png"},"c39de7f5-4ffa-4ad4-8b55-9db3bfbe6751":{"name":"sunANDmoon","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":2,"looping":true,"frameDelay":12,"version":"_rnRDxINkoCJWqkkTtIo07fciYOh8SjT","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":200},"rootRelativePath":"assets/c39de7f5-4ffa-4ad4-8b55-9db3bfbe6751.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

//initiate Game STATEs
var PLAY = 1;
var END = 0;
var gameState = PLAY;
var ground = createSprite(400,200,0,0);
//create a trex sprite
var trex = createSprite(200,380,20,50);
trex.setAnimation("trex");

//set collision radius for the trex
trex.setCollider("circle",0,0,30);

//scale and position the trex
trex.scale = 0.75;
trex.x = 100;

//create a ground sprite
ground.setAnimation("background1");
ground.x = ground.width /2;

//invisible Ground to support Trex
var invisibleGround = createSprite(200,385,400,5);
invisibleGround.visible = false;

//create Obstacle and Cloud Groups
var ObstaclesGroup = createGroup();
var CloudsGroup = createGroup();

//place gameOver and restart icon on the screen
var gameOver = createSprite(200,300);
var restart = createSprite(200,340);
var sunAndMoon = createSprite(175,75);

ground.scale = 4;
gameOver.setAnimation("gameOver");
gameOver.scale = 0.5;
restart.setAnimation("restart");
restart.scale = 0.5;
sunAndMoon.setAnimation("sunANDmoon");
sunAndMoon.scale = 1;


gameOver.visible = false;
restart.visible = false;

//set text
textSize(18);
textFont("Georgia");
textStyle(BOLD);

//score
var count = 0;

function draw() {
  //set background to white
  background("white");
  //display score

  if(gameState === PLAY){
    //move the ground
    ground.velocityX = -(6 + 3*count/100);
    //scoring
   //count = Math.round(World.frameCount/4);
   count = count+Math.round(World.frameRate/20);
    if (count>0 && count%100 === 0){
      playSound("assets/checkPoint.mp3");
    }
    
    if (ground.x < 0){
      ground.x = ground.width/2;
    }

     if (count >= 600) {
  playSound("assets/category_achievements/peaceful_win_2.mp3", false);
      gameState = END;
  }
     //jump when the space key is pressed
    if(keyDown("space") && trex.y >= 359){
      trex.velocityY = -12 ;
      playSound("assets/jump.mp3");
    }
  
    //add gravity
    trex.velocityY = trex.velocityY + 0.8;
    
    //spawn the clouds
    spawnClouds();
  
    //spawn obstacles
    spawnObstacles();
          text("Score: "+ count, 250, 100);
    //End the game when trex is touching the obstacle
    if(ObstaclesGroup.isTouching(trex)){
      gameState = END;
      playSound("assets/die.mp3");
    }
  }
  
  else if(gameState === END) {
    gameOver.visible = true;
    restart.visible = true;
    
    //set velcity of each game object to 0
    ground.velocityX = 0;
    trex.velocityY = 0;
    ObstaclesGroup.setVelocityXEach(0);
    CloudsGroup.setVelocityXEach(0);
    
    //change the trex animation
    trex.setAnimation("trex_collided");
    
    //set lifetime of the game objects so that they are never destroyed
    ObstaclesGroup.setLifetimeEach(-1);
    CloudsGroup.setLifetimeEach(-1);
    if(mousePressedOver(restart)) {
    reset();
  }
    
  }
  
  
  
  //console.log(trex.y);
  
  //stop trex from falling down
  trex.collide(invisibleGround);
  
  drawSprites();
}

function reset(){
gameState = PLAY; 
gameOver.visible = false;
restart.visible = false;
ObstaclesGroup.destroyEach();
CloudsGroup.destroyEach();
trex.setAnimation("trex");
count = 0;
}

function spawnObstacles() {
  if(World.frameCount % 60 === 0) {
    var obstacle = createSprite(400,365,10,40);
    obstacle.velocityX = - (6 + 3*count/100);
    
    //generate random obstacles
    var rand = randomNumber(1,6);
    obstacle.setAnimation("obstacle" + rand);
    
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.15;
    obstacle.lifetime = 70;
    //add each obstacle to the group
    ObstaclesGroup.add(obstacle);
  }
}

function spawnClouds() {
  //write code here to spawn the clouds
  if (World.frameCount % 60 === 0) {
    var cloud = createSprite(400,320,40,10);
    cloud.y = randomNumber(150,280);
    cloud.setAnimation("cloud");
    cloud.scale = 0.25;
    cloud.velocityX = -3;
    
     //assign lifetime to the variable
    cloud.lifetime = 134;
    
    //adjust the depth
    cloud.depth = trex.depth;
    trex.depth = trex.depth + 1;
    
    //add each cloud to the group
    CloudsGroup.add(cloud);
  }
 
  
  
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
